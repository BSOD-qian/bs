---
layout: 'layouts\article.njk'
title: 'An unforgettable experience'
---
# #7 An unforgettable experience
It was a Wednesday evening. When I went back home, no one was in. So I cooked the meal. I didn't know my mother was ill until my parents came back from the hospital. They both said the meal was very delicious, although it tasted salty. After supper, I found they were too tired, so I got a basin of hot water for them. When my mother put her feet into the water, with tears in her eyes she said, "Dear, you have grown up."
 It was an unforgettable experience, because I started to care about my parents and I realized I was not a child any more.