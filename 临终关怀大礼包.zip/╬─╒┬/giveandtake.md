---
layout: 'layouts\article.njk'
title: 'Give and take'
---
# #11 Give and take
It is a common belief that those who offer help or unselfish service to those in need will be happier with the act of giving. In the process of giving, you are sure to get something.
In my point of view, everyone should help those in need. For example, if our classmates come across difficult problems, we should try our best to help them solve these problems. Then we may improve our friendships, and they may give a hand to us when we have trouble. Apart from that, we can also achieve happiness through helping others.
Helping others really can make us happier and healthier.
Remember, the more you give, the more you receive.