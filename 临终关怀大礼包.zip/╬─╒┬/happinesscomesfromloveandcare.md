---
layout: 'layouts\article.njk'
title: 'Happiness comes from love and care'
---
# #8 Happiness comes from love and care
As we all know, happiness is one of the most important things in our life. Some people think happiness is being healthy. Others think earning a lot of money is a kind of happiness. As far as I am concerned, I think happiness comes from love and care.
First, we should care for our parents. We mustn’t argue with them when they give us sincere advice. On the contrary, we should listen to the suggestions patiently and take the good advice. In addition, we ought to take action to help them do the housework and reduce their burden.
Second, we should care for the elderly. For example, we can give our seats to the elderly when we are on a bus. We should also go to a nursing home to do volunteer work. This will make the senior citizens feel less lonely. Meanwhile, we can feel extremely happy by doing so. 
To sum up, happiness is made up of love and care. And I believe that if we care for others sincerely, our life will be full of happiness.