---
layout: 'layouts\article.njk'
title: 'How to spend a meaningful holiday'
---
# #6 How to spend a meaningful holiday
The winter holiday is coming. I’m going to have a good rest and learn to relax myself. I will read more useful books because reading more books is not only interesting but also can make me learn more knowledge. I will try to spend more time in chatting with my parents and help them to do some housework. I am going to take part in the social activities so that I can know more about the society. If possible, I’d like to go to Beijing for a visit of Beijing University. I’m sure I’ll have an interesting and meaningful winter holiday.