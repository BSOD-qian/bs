---
layout: 'layouts\article.njk'
title: 'Learn to smile'
---
# #4 Learn to smile
Smile is an attitude towards life. As we all know, life is not always smooth and something sad will happen to us, such as failure in the exam. However, we should learn to smile to ourselves. Smile makes us feel more confident. If we smile to the others, we will be much closer to our friends. Smile is the common language throughout the whole world that everyone can understand. Therefore, in order to make life better, just keep smiling to ourselves as well as to everyone around us.