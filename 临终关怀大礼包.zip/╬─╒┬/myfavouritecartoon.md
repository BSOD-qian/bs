---
layout: 'layouts\article.njk'
title: 'My favourite cartoon'
---
# #1 My favourite cartoon
 My favourite cartoon is Pleasant Goat and Big Big Wolf. It has been the most popular cartoon in China since 2005.
 The cartoon tells us stories about how some young and brave goats fight against two wolves who want to hurt them. The stories are very interesting. Big Big Wolf thinks of many ways to catch goats as his food, but the smart goats fight against wolves for their lives and friendship, so Big Big Wolf fails every time. Not only children are interested in the cartoon but their parents and even their grandparents also like to watch it. You can stay at home and watch it. Don’t miss it.