---
layout: 'layouts\article.njk'
title: 'My view on homework'
---
# #10 My view on homework
Nowadays, many students are required to do a lot of homework to get a high score. Parents think doing homework is an essential part of education.
But in my opinion, doing a large amount of homework isn’t helpful to students. It may cause a lot of problems. On one hand, doing too much homework makes us have less time to rest. We may feel tired and haven’t enough energy to listen to teachers carefully in class. It’s bad for our health. On the other hand, the quality of our homework would often be compared with others’. Indeed, this kind of comparison makes many students feel stressed. More importantly, because of too much homework, we don’t have enough time to do the things we really want to do. We younger generation need enough space and time to develop our own interests.
How I wish I could have less homework!