---
layout: 'layouts\article.njk'
title: 'Reading — A Good Habit'
---
# #2 Reading — A Good Habit
Reading is a very good habit. I like reading very much. In my eyes, forming a good reading habit is necessary for us. It can not only improve our knowledge but also make us think over more different things efficiently. 
Besides, we can do some reading every time we are free. For example, I often read some of my favourite books in my spare time both at home or in the library. What I like most are storybooks because most of them are quite interesting. Now I often buy my favourite books online at a big discount. 
Finally, I like to share my favourite books with my family or my classmates. Since reading can benefit us a lot, it’s time for us to have our good reading habit now!