---
layout: 'layouts\article.njk'
title: 'The Way(s) I learn English'
---
# #5 The Way(s) I learn English
English has been a kind of popular language. As a student, I have learned it for eight years.
There are many good ways of learning English, but I think the best way is to practise using English. The more times you practise, the more knowledge you will know.
In my daily life, I usually listen to the English radio or read English newspapers because they can help me improve my skills in listening and reading. In addition, I also do enough exercises to improve abilities of writing. Sometimes, I talk with my classmates in English so that I can practise speaking.
If you do these things above, I am sure that your English will be better.