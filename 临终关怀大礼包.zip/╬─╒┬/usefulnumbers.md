---
layout: 'layouts\article.njk'
title: 'Useful numbers'
---
# #9 Useful numbers
During the past three years in the middle school, I have had many unforgettable experiences. One of them was when our class prepared for the choir contest. During the week before the contest, we practised singing in our free time. Although it was a hard job, every classmate took it seriously and did their best. Thanks to our efforts, we won the first prize. Hearing the exciting news, we were all wild with joy. The moment we got the prize, an old saying hit my mind— No pains, no gains. It was hard work, but during the course of preparation, we developed friendship, confidence as well as understanding.